document.addEventListener('DOMContentLoaded', () => {

    //LÓGICA PARA PAG DE PRODUTO ---->
    
    //seleciona todos os botões com a classe 'add-to-cart-brn'
    const addToCartButtons = document.querySelectorAll('.adicionar-carrinho');

    //intera sobre cada botão encontrado. 'forEach' é um laço de repetição 
    addToCartButtons.forEach(button =>{
        button.addEventListener('click', () =>{

            //adiona um 'ouvinte de evento' de clique para cada botão
            //quando o botão for clicado a função 'addeventlist.... será executada
            const card = button.closest('.card');//button.closest encontra o elemento pai
            const productName = card.getAttribute('data-name');//pega o nome do produto através 
            const productPrice = parseFloat(card.getAttribute('data-price'));

            const product = {//cria um objeto 'product' para armazenar as informações do item
                name: productName,
                price: productPrice,
            };

            //vamos pegar o carrinho atual do 'localStorage' do navegador
            //json.parse converte a string do localStorage de volta para um objeto
            //se não houver nada no carrinho, inicializamos a array vazia []
            let cart = JSON.parse(localStorage.getItem('cart')) || [];
            cart.push(product);//adiciona o produto novo

            //Vamos salvar o array no carrinho atualizado
            //'JSON;stringify' converte o objeto/array em String para armazenar
            localStorage.setItem('cart', JSON.stringify(cart));

            //agora vamos adicionar um alerta simples
            alert(`${productName}Foi adicionado ao carrinho!`)
        })
    })

    //logica para a pag de carrinho

    //criando as variaveis e selecionando elementos
    const cardItensContainer = document.getElementById('card-items-container');
    const cardTotalValue = document.getElementById('card-total-value');
    const checkoutBtn = document.getElementById('checkout-btn');

    //Verifica se estamos na pagina do carrinho 
    if(cardItensContainer){
        //Pega os itens 'armazenados no navegador'
        const cart = JSON.parse(localStorage.getItem('cart')) || [];
        let total = 0;

        if(cart.length === 0){
            //Se o carrinho estiver vazio, mostra a mensagem do html
        }else{
            //mas se houver itens, limpa o conteudo padrão
            cardItensContainer.innerHTML = "";

            //vamos descobrir os itens
            cart.forEach(product => {
                const cartItem = document.createElement('div');
                cartItem.classList.add('cart-item');

            //Definimos o conteudo HTML
            //to.fixed formata para ter duas casas decimais
            cartItem.innerHTML = `
            <span>${product.name}</span>
            <span>R$ ${product.price.toFixed(2)}</span>
            `;
            

            cardItensContainer.appendChild(cartItem);

            //soma o preço de cada produto
            total += product.price;
            })
        }
        //atualizar o texto do valor total da página
        cardTotalValue.textContent = `R$ ${total.toFixed(2)}`;

        checkoutBtn.addEventListener('click', () => {
            const numeroWhatsApp = '5515999230023'
            
            //montar mensagem do pedido
            let mensagem = 'Olá, Segue meu pedido: \n \n';
            cart.forEach(product => { 
            mensagem += `- ${product.name} (R$ ${product.price.toFixed(2)})\n`
            });
            mensagem += `\n*Total: R$ ${total.toFixed(2)}*`;

            const urlWhatsApp = `https://wa.me/${5515999230023}?text=${encodeURIComponent(mensagem)}`;
            window.open(urlWhatsApp, '_blank');
            localStorage.removeItem('cart');
        
    });
}    
    const limparTabela = document.getElementById('limpar-pedido');
    limparTabela.addEventListener('click', () =>{
        localStorage.removeItem('cart');
        location.reload(true)
    })
});